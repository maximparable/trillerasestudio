git: https://github.com/liberationfonts/liberation-fonts.git

See FONTS.LICENSE for the license.
